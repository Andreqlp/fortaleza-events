<?php 

/* Custom field For Adding title in Other language */

//    add_action( 'admin_init', '_admin_init' );
//    add_action( 'save_post', '_save_post' );
//    add_action( 'admin_enqueue_scripts', '_add_admin_scripts');
//    
//    
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/metaboxes/country_details.php';
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/metaboxes/regions_details.php';
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/metaboxes/news_details.php';
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/metaboxes/certificates_details.php';
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/metaboxes/awards_details.php';
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/metaboxes/product_details.php';
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/metaboxes/brand_details.php';
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/metaboxes/company_details.php';
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/metaboxes/company_other_metabox.php';
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/metaboxes/custom_page.php';
//    
//    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'classes/categories-images.php';
    
        
