<?php
/** @wordpress-plugin
 * Author:            Amplugin
 * Author URI:        http://amplugin.com/
 */
// ShortCodes For plugins
global $cwebPluginName;
global $PluginTextDomain;
global $wpdb;

function agenda_listing() {
       //echo 'hiiiiiiii';

}
add_shortcode('agenda_listing', 'agenda_listing');
